/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   handler.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hrasargs <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/14 21:48:57 by hrasargs          #+#    #+#             */
/*   Updated: 2025/09/14 23:34:49 by hrasargs         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "handler.h"
#include "tools.h"

int	ft_atoi(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= '0' && str[i] <= '9'))
			return (0);
		i++;
	}
	i = 0;
	if (str[i] == '0' && (str[i + 1] >= '0' && str[i + 1] <= '9'))
		return (0);
	return (1);
}

int	max(char **mat)
{
	int	i;
	int	maximum;

	maximum = ft_strlen(mat[0]);
	i = 1;
	while (mat[i])
	{
		if (maximum < ft_strlen(mat[i]))
			maximum = ft_strlen(mat[i]);
		i++;
	}
	return (maximum);
}

int	in_range(char *str, char **mat)
{
	int	max_len;
	int	str_len;
	int	i;

	i = 0;
	str_len = ft_strlen(str);
	max_len = max(mat);
	if (str_len > max_len + 2 || str_len < 1)
		return (0);
	return (1);
}

int	count_rows(char **mat)
{
	int	i;

	i = 0;
	while (mat[i])
		i++;
	return (i);
}
