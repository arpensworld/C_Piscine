/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tools.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hrasargs <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/14 18:10:14 by hrasargs          #+#    #+#             */
/*   Updated: 2025/09/14 21:34:03 by hrasargs         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TOOLS_H
# define TOOLS_H

int	ft_strlen(char *str);
int	ft_strncmp(char *s1, char *s2, unsigned int nb);
int	ft_is_zeros(char *temp);

#endif
