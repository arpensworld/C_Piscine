/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hrasargs <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/14 14:48:35 by hrasargs          #+#    #+#             */
/*   Updated: 2025/09/14 23:29:38 by hrasargs         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "convert.h"

int	is_sep(char c)
{
	if (c == ':' || c == ' ' || c == '\n')
		return (1);
	return (0);
}

int	count_words(char *str)
{
	int	count;
	int	i;

	i = 0;
	count = 0;
	while (str[i] != '\0')
	{
		while (str[i] != '\0' && is_sep(str[i]))
			i++;
		if (str[i] != '\0' && !is_sep(str[i]))
		{
			count++;
			while (str[i] != '\0' && !is_sep(str[i]))
				i++;
		}
	}
	return (count);
}

char	*word(char *str)
{
	int			len;
	int			i;
	char		*w;

	i = 0;
	len = 0;
	while (str[len] && !is_sep(str[len]))
		len++;
	w = (char *)malloc((len + 1) * sizeof(char));
	while (i < len)
	{
		w[i] = str[i];
		i++;
	}
	w[i] = '\0';
	return (w);
}

void	single_line(char *path, char **mat, int row)
{
	int		i;
	int		j;
	int		fd;
	int		*arr;
	char	*temp;

	i = 0;
	j = 0;
	fd = open(path, O_RDONLY);
	arr = word_count(path, row);
	while (i < row)
	{
		temp = (char *)malloc((arr[i] + 1) * sizeof(char));
		read(fd, temp, arr[i] + 1);
		temp[arr[i] + 1] = '\0';
		ft_split(temp, mat, &j);
		free(temp);
		i++;
	}
	close(fd);
}

void	ft_split(char *temp, char **mat, int *i)
{
	while (*temp)
	{
		while (*temp && is_sep(*temp))
			temp++;
		if (*temp && !is_sep(*temp))
		{
			mat[*i] = word(temp);
			*i += 1;
			while (*temp && !is_sep(*temp))
				temp++;
		}
	}
}
