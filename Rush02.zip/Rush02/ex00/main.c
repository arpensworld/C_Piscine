/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hrasargs <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/13 17:12:06 by hrasargs          #+#    #+#             */
/*   Updated: 2025/09/14 23:25:23 by hrasargs         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include "convert.h"
#include "solve.h"
#include "tools.h"
#include "handler.h"
#include "memory.h"

int	perform(char **mat, char *arg, char *path)
{
	int	rows;
	int	arg_len;

	rows = count_rows(mat);
	arg_len = ft_strlen(arg);
	single_line(path, mat, 2 * rows);
	if (!in_range(arg, mat))
		return (write(1, "Dict Error\n", 10), -1);
	solve(arg, mat, arg_len, 0);
	return (0);
}

int	main(int argc, char **argv)
{
	char	*path;
	char	**mat;

	if (argc < 2)
		return (write(1, "Error\n", 6), -1);
	else if (argc == 2)
	{
		path = "numbers.dict";
		mat = convert(path);
	}
	else if (argc == 3)
	{
		path = argv[2];
		mat = convert(path);
	}
	else
		return (write(1, "Error\n", 6), -1);
	if (!ft_atoi(argv[1]))
		return (write(1, "Error\n", 6), -1);
	else
		return (perform(mat, argv[1], path));
	return (0);
}
