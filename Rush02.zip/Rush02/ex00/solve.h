/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hrasargs <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/14 18:01:03 by hrasargs          #+#    #+#             */
/*   Updated: 2025/09/14 23:31:36 by hrasargs         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SOLVE_H
# define SOLVE_H

# include <unistd.h>
# include <stdlib.h>

void	solve1(char *arg, char **mat, int len, char *temp);
char	*solve(char *arg, char **mat, int len, int counter);
int		check_array(char *arg, char **mat, unsigned int nb);
int		check_symbol(char c, char **mat);
void	put_zeros(int counter, char **mat);
int		ft_is_zero(char *temp);

#endif
