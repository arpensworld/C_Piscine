/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   convert.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hrasargs <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/14 14:17:13 by hrasargs          #+#    #+#             */
/*   Updated: 2025/09/14 22:58:06 by hrasargs         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "convert.h"

#define COL_COUNT 2

char	**convert(char *path)
{
	int		fd;
	int		i;
	int		row;
	char	c;
	char	**mat;

	row = 0;
	i = 0;
	fd = open(path, O_RDONLY);
	if (fd < 0)
		return (write(1, "Dict Error\n", 10), NULL);
	else
	{
		while (read(fd, &c, 1))
			if (c == '\n')
				row++;
		mat = (char **)malloc((row + 1) * sizeof(char *));
		while (i < row)
			mat[i++] = (char *)malloc(COL_COUNT * sizeof(char));
		mat[row] = NULL;
		return (mat);
	}
	close(fd);
	return (NULL);
}

int	*word_count(char *path, int row)
{
	char	c;
	int		fd;
	int		i;
	int		size;
	int		*sizes;

	i = 0;
	sizes = (int *)malloc((row + 1) * sizeof(int));
	fd = open(path, O_RDONLY);
	while (i < row && read(fd, &c, 1))
	{
		size = 0;
		while (c != '\n')
		{
			read(fd, &c, 1);
			size++;
		}
		sizes[i] = size;
		i++;
	}
	close(fd);
	return (sizes);
}
