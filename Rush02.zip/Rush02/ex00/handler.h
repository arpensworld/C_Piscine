/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   handler.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hrasargs <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/14 21:47:48 by hrasargs          #+#    #+#             */
/*   Updated: 2025/09/14 22:24:15 by hrasargs         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HANDLER_H
# define HANDLER_H

int	ft_atoi(char *str);
int	in_range(char *str, char **mat);
int	max(char **mat);
int	count_rows(char **mat);

#endif
