/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hrasargs <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/14 18:02:13 by hrasargs          #+#    #+#             */
/*   Updated: 2025/09/14 23:31:20 by hrasargs         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solve.h"
#include "tools.h"

void	solve1(char *arg, char **mat, int len, char *temp)
{
	int		i;
	char	c;

	i = 0;
	if (len == 3 && !ft_is_zeros(arg))
	{
		check_symbol(temp[0], mat);
		write(1, " ", 1);
		check_array("100", mat, ft_strlen("100"));
		i = 1;
		write(1, " ", 1);
	}
	c = temp[i + 1];
	temp[i + 1] = '0';
	check_array(temp + i, mat, 2);
	write(1, " ", 1);
	check_symbol(c, mat);
}

char	*solve(char *arg, char **mat, int len, int counter)
{
	int		i;
	char	*temp;

	temp = (char *)malloc(len * sizeof(temp));
	if (len > 3)
	{
		arg = solve(arg, mat, len - 3, counter + 3);
		len = 3;
	}
	i = 0;
	while (i < len)
	{
		temp[i] = arg[i];
		i++;
	}
	if (ft_is_zeros(temp))
		return (arg + len);
	if (!check_array(temp, mat, len))
		solve1(arg, mat, len, temp);
	if (!ft_is_zeros(arg))
		put_zeros(counter, mat);
	return (arg + len);
}

int	check_array(char *arg, char **mat, unsigned int nb)
{
	int	i;
	int	len;

	i = 0;
	while (mat[i])
	{
		if (!ft_strncmp(arg, mat[i], nb))
		{
			len = ft_strlen(mat[i + 1]);
			write(1, mat[i + 1], len);
			return (1);
		}
		i++;
	}
	return (0);
}

int	check_symbol(char c, char **mat)
{
	int	i;
	int	len;

	i = 2;
	while (mat[i])
	{
		if (c == mat[i][0])
		{
			len = ft_strlen(mat[i + 1]);
			write(1, mat[i + 1], len);
			return (1);
		}
		i++;
	}
	return (0);
}

void	put_zeros(int counter, char **mat)
{
	char	*arr;
	int		i;

	if (counter < 3)
		return ;
	i = 1;
	arr = (char *)malloc((counter + 2) * sizeof(char));
	arr[0] = '1';
	while (i <= counter)
		arr[i++] = '0';
	arr[i] = '\0';
	write(1, " ", 1);
	check_array(arr, mat, ft_strlen(arr));
	write(1, " ", 1);
}
