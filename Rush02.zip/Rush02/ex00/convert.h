/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   convert.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hrasargs <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/14 14:15:26 by hrasargs          #+#    #+#             */
/*   Updated: 2025/09/14 23:30:17 by hrasargs         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CONVERT_H
# define CONVERT_H

# include <fcntl.h>
# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>

char	**convert(char *path);
int		*word_count(char *path, int row);
void	single_line(char *path, char **mat, int row);
char	*word(char *str);
int		count_words(char *str);
int		is_sep(char c);
void	ft_split(char *temp, char **mat, int *i);
#endif
